# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Development Commands

### Common pnpm commands (run from workspace root):
- `pnpm install` - Install all dependencies
- `pnpm run build` - Build all packages
- `pnpm run typecheck` - Run TypeScript type checking across all packages

### API Server (artifacts/api-server):
- `pnpm --filter @workspace/api-server run dev` - Start development server
- `pnpm --filter @workspace/api-server run build` - Build server
- `pnpm --filter @workspace/api-server run start` - Start built server
- `pnpm --filter @workspace/api-server run typecheck` - Type check server code

### Chat UI (artifacts/chat-ui):
- `pnpm --filter @workspace/chat-ui run dev` - Start development UI
- `pnpm --filter @workspace/chat-ui run build` - Build UI for production
- `pnpm --filter @workspace/chat-ui run serve` - Preview built UI
- `pnpm --filter @workspace/chat-ui run typecheck` - Type check UI code

### Libraries:
Run commands with appropriate filters, e.g.:
- `pnpm --filter @workspace/api-client-react run typecheck`
- `pnpm --filter @workspace/db run typecheck`

## Code Architecture

### Monorepo Structure:
- **artifacts/** - Deployable applications
  - `api-server/` - Express-based backend API
  - `chat-ui/` - React/Vite frontend application
  - `mockup-sandbox/` - Example React component library
- **lib/** - Shared libraries and packages
  - `api-spec/` - OpenAPI specification and generated clients
  - `api-client-react/` - React API client wrapper
  - `api-zod/` - Zod schema generation and validation
  - `db/` - Database layer using Drizzle ORM
  - `integrations-*` - AI service integrations (Anthropic, Gemini, OpenAI)
- **scripts/** - Utility scripts

### Key Technologies:
- **Backend**: Node.js, Express, TypeScript, Drizzle ORM
- **Frontend**: React, Vite, Tailwind CSS, Radix UI components
- **Type Safety**: End-to-end TypeScript with zod schemas
- **Build**: esbuild for server, Vite for client
- **Package Manager**: pnpm workspaces

### Development Practices:
- Strict TypeScript configuration (noImplicitAny, strictNullChecks, etc.)
- Component library uses Radix UI primitives
- API contracts defined in OpenAPI spec with automatic client generation
- Environment-based configuration (development/production)