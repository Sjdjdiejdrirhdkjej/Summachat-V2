<!-- 9021c223-ecdf-4386-87e0-f20d3ddd151b -->
---
todos:
  - id: "classify-failure"
    content: "Capture Replit build vs run logs and classify failure (install/build/start/health/runtime)"
    status: pending
  - id: "validate-prune"
    content: "Reproduce deploy locally: build → pnpm prune --prod → run server → curl /api/healthz; adjust or remove postBuild if broken"
    status: pending
  - id: "align-build-docs"
    content: "Decide: extend deployment.build with root typecheck/build vs commit-only codegen; update replit.md health paths"
    status: pending
  - id: "cleanup-health-artifacts"
    content: "Remove duplicate health/index.ts or consolidate; reconcile .replit artifacts vs .replitignore for mockup-sandbox"
    status: pending
  - id: "optional-hardening"
    content: "If timeouts: trim root prod deps; verify NODE_ENV; audit secrets in versioned .replit"
    status: pending
isProject: false
---
# Plan: Fix Replit deployment issues

## Current deployment shape (baseline)

- **[`.replit`](.replit)** — Autoscale deployment: `build` runs chat-ui then api-server; `run` starts `node --enable-source-maps artifacts/api-server/dist/index.mjs`; `deployment.postBuild` runs `pnpm prune --prod`; health probe uses `startupPath = "/api/healthz"`.
- **Express** — [`artifacts/api-server/src/app.ts`](artifacts/api-server/src/app.ts) mounts API at `/api`, then serves Vite output from `artifacts/chat-ui/dist/public` when `index.html` exists (SPA fallback for non-`/api/*` routes).
- **Startup vs optional deps** — [`artifacts/api-server/src/routes/index.ts`](artifacts/api-server/src/routes/index.ts) loads `/images`, chat, and multi-chat via lazy `import()` so provider/DB-heavy modules are not required for process start; [`lib/db/src/index.ts`](lib/db/src/index.ts) throws if `DATABASE_URL` is missing **when that module is first evaluated** (first hit to `/api/images` that loads [`images.ts`](artifacts/api-server/src/routes/images.ts)), not for `/api/healthz`.

```mermaid
flowchart LR
  subgraph deploy [Replit deploy]
    Install[pnpm install]
    Build[build chat-ui + api-server]
    Prune[postBuild pnpm prune --prod]
    Run[node dist/index.mjs]
  end
  Install --> Build --> Prune --> Run
  Run --> Health[GET /api/healthz]
  Run --> API["/api/* routes"]
  Run --> SPA[static + index.html fallback]
```

## Step 1: Classify the failure (required before “fixing” blindly)

Replit failures usually fall into one bucket; the fix differs:

1. **Install** — `minimumReleaseAge`, lockfile drift, or network.
2. **Build** — TypeScript/Vite/esbuild errors; missing generated OpenAPI clients; chat-ui build before libs.
3. **Start** — `node` exits immediately (uncaught exception, missing file).
4. **Health check** — process runs but `/api/healthz` never returns 200 in time (wrong path, crash before listen, timeout).
5. **Runtime** — deploy healthy but API/UI errors (CORS, env, DB on first use).

**Action:** From the Replit Deployments panel (or build logs), capture whether the error is build-time or run-time, and paste the first stack trace or failing command. That confirms which of the following steps apply.

## Step 2: Validate `pnpm prune --prod` (high-signal suspect)

[`[deployment.postBuild]`](.replit) runs `pnpm prune --prod` with `CI=true`. In monorepos this can occasionally remove packages that are still referenced indirectly (e.g. optional tooling, worker subpaths, or workspace edge cases).

**Action:**

- Reproduce locally from a clean tree: full install → same build line as `.replit` → `pnpm prune --prod` → `NODE_ENV=production node artifacts/api-server/dist/index.mjs` → `curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:8080/api/healthz`.
- If the app breaks only after prune, either **remove `postBuild`** (simplest) or replace it with a **documented, reproducible packaging strategy** (e.g. `pnpm deploy` into a deploy directory, if you adopt that workflow) so production `node_modules` matches what the bundle and workers need.

## Step 3: Align the deployment build with what the repo guarantees

Root `pnpm run build` runs root **typecheck** then recursive **build**; Replit’s `deployment.build` only runs two filters and **skips root typecheck**.

**Action:**

- If deploy builds fail due to stale generated clients or ordering, either:
  - **Add** `pnpm run typecheck` or `pnpm run build` to the deployment build (slower but consistent with [`package.json`](package.json)), or
  - **Document** that OpenAPI/codegen must be committed before deploy (current AGENTS.md workflow).

## Step 4: Fix configuration drift and confusion

| Item | Issue | Suggested fix |
|------|--------|----------------|
| Health path docs | [`replit.md`](replit.md) still describes `GET /health` under older wording; actual route is under `/api` | Update docs to `GET /api/healthz` (and optional `/api/readyz`) to match [`health.ts`](artifacts/api-server/src/routes/health.ts) and [`.replit`](.replit) |
| Duplicate health module | [`artifacts/api-server/src/routes/health/index.ts`](artifacts/api-server/src/routes/health/index.ts) duplicates `/healthz` but [`routes/index.ts`](artifacts/api-server/src/routes/index.ts) imports `./health` (resolves to `health.ts`), so `health/index.ts` is likely dead | Remove or merge into one module to avoid future edits landing on the wrong file |
| Artifacts list | [`.replit`](.replit) registers `artifacts/mockup-sandbox` while [`.replitignore`](.replitignore) excludes it from published images | Confirm with Replit’s artifact UX whether the extra artifact causes noise; trim or document intentional multi-artifact dev setup |

## Step 5: Optional hardening (if issues persist)

- **Env at runtime:** Ensure production has `NODE_ENV=production` (Replit often sets this); integrations (`AI_INTEGRATIONS_*`) are only required when lazy API routes load, not for health—if health fails, look for **non-lazy** imports or startup side effects (none found for `@workspace/db` except `images.ts`).
- **Root `package.json` dependencies:** Large CLI-style packages are listed under root **dependencies**; they inflate install size and can stress deploy timeouts. If install time is the failure mode, consider moving dev-only CLIs to **devDependencies** (verify nothing in deploy relies on them).
- **Secrets:** [`.replit`](.replit) contains `userenv.shared` entries; ensure API keys are not committed if this file is public—rotate if needed (security, not strictly “deploy”, but often paired with “deployment broke after sharing repo”).

## Success criteria

- Deploy build completes without error.
- Process stays up and Replit’s health check passes against `/api/healthz` within the platform timeout.
- Opening the deployment URL serves the SPA and `/api/*` responds as expected (lazy routes may return 503 until secrets/DB are configured—by design).
